/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import DAO.ReservasiDAO;
import TR_Hotel.Reservasi;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class ReservasiController {
    public ReservasiDAO dao = new ReservasiDAO();
    
    public List<Reservasi> getAll() {
        return dao.getAll();
    }
    
    public List<Reservasi> getno_pesan(String kode) {
        return dao.getno_pesan(kode);
    }
    
    public List<Reservasi> getnama_tamu(String kode) {
        return dao.getnama_tamu(kode);
    }

    public List<Reservasi> getgender_tamu(String kode) {
        return dao.getgender_tamu(kode);
    }

    public List<Reservasi> getalamat(String kode) {
        return dao.getalamat(kode);
    }
    
    public List<Reservasi> getjenis_kamar(String kode) {
        return dao.getjenis_kamar(kode);
    }
    
    public List<Reservasi> getharga(int kode) {
        return dao.getharga(kode);
    }
    
    public List<Reservasi> getlama_inap(int kode) {
        return dao.getlama_inap(kode);
    }
    
    public List<Reservasi> gettotal(int kode) {
        return dao.gettotal(kode);
    }
    
    public String tambahTamu(Reservasi rv) {
        return this.dao.insertTamu(rv);
    }

    public String deleteTamu(String kode) {
        return this.dao.hapusTamu(kode);
    }

    public String editTamu(String kode, Reservasi rsvp) {
        return this.dao.updateTamu(kode, rsvp);
    }
    public boolean cekkode(String kode) {
        return this.dao.cekkode(kode);
    }
}
