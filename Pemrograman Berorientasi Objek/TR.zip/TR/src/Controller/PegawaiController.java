/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import DAO.PegawaiDAO;
import java.util.List;
import TR_Hotel.Pegawai;

public class PegawaiController {
    public PegawaiDAO dao = new PegawaiDAO();
    
    public List<Pegawai> getAll() {
        return dao.getAll();
    }
    
    public List<Pegawai> getkode_pegawai(String kode) {
        return dao.getkode_pegawai(kode);
    }
    
    public List<Pegawai> getnama_pegawai(String kode) {
        return dao.getnama_pegawai(kode);
    }

    public List<Pegawai> getgender_pegawai(String kode) {
        return dao.getgender_pegawai(kode);
    }

    public List<Pegawai> getposisi(String kode) {
        return dao.getposisi(kode);
    }

    public List<Pegawai> getalamat(String kode) {
        return dao.getalamat(kode);
    }
    
    public List<Pegawai> getno_telepon(String kode) {
        return dao.getno_telepon(kode);
    }
    
    public List<Pegawai> getmasa_kerja(int kode) {
        return dao.getmasa_kerja(kode);
    }
    
    public List<Pegawai> getgaji(int kode) {
        return dao.getgaji(kode);
    }
    
    public String tambahPegawai(Pegawai pg) {
        return this.dao.insertPegawai(pg);
    }

    public String hapusPegawai(String kode) {
        return this.dao.hapusPegawai(kode);
    }

    public String editPegawai(String kode, Pegawai employee) {
        return this.dao.updatePegawai(kode, employee);
    }
    public boolean cekkode(String kode) {
        return this.dao.cekkode(kode);
    }
}
