/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TR_Hotel;

/**
 *
 * @author Lenovo
 */
public class Reservasi {
    private String no_pesan;
    private String nama_tamu;
    private String gender_tamu;
    private String alamat;    
    private String jenis_kamar;
    private int harga;
    private int lama_inap;
    private int total;
    
    public String getno_pesan() {
        return no_pesan;
    }

    public void setno_pesan(String no_pesan) {
        this.no_pesan = no_pesan;
    }
    
    public String getnama_tamu() {
        return nama_tamu;
    }

    public void setnama_tamu(String nama_tamu) {
        this.nama_tamu = nama_tamu;
    }
    
    public String getgender_tamu() {
        return gender_tamu;
    }

    public void setgender_tamu(String gender_tamu) {
        this.gender_tamu = gender_tamu;
    }

    public String getalamat() {
        return alamat;
    }

    public void setalamat(String alamat) {
        this.alamat = alamat;
    }
    
    public String getjenis_kamar() {
        return jenis_kamar;
    }

    public void setjenis_kamar(String jenis_kamar) {
        this.jenis_kamar = jenis_kamar;
    }
        
    public int getharga() {
        return harga;
    }

    public void setharga(int harga) {
        this.harga = harga;
    }
    
    public int getlama_inap() {
        return lama_inap;
    }

    public void setlama_inap(int lama_inap) {
        this.lama_inap = lama_inap;
    }
    
    public int gettotal() {
        return total;
    }

    public void settotal(int total) {
        this.total = total;
    }
}
