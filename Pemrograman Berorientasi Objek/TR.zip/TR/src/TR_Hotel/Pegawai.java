/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TR_Hotel;

/**
 *
 * @author Lenovo
 */
public class Pegawai {
    private String kode_pegawai;
    private String nama_pegawai;
    private String gender_pegawai;
    private String posisi;
    private String alamat;    
    private String no_telepon;
    private int masa_kerja;
    private int gaji;
    
    public String getkode_pegawai() {
        return kode_pegawai;
    }

    public void setkode_pegawai(String kode_pegawai) {
        this.kode_pegawai = kode_pegawai;
    }
    
    public String getnama_pegawai() {
        return nama_pegawai;
    }

    public void setnama_pegawai(String nama_pegawai) {
        this.nama_pegawai = nama_pegawai;
    }
    
    public String getgender_pegawai() {
        return gender_pegawai;
    }

    public void setgender_pegawai(String gender_pegawai) {
        this.gender_pegawai = gender_pegawai;
    }

    public String getposisi() {
        return posisi;
    }

    public void setposisi(String posisi) {
        this.posisi = posisi;
    }
    
    public String getalamat() {
        return alamat;
    }

    public void setalamat(String alamat) {
        this.alamat = alamat;
    }
    
    public String getno_telepon() {
        return no_telepon;
    }

    public void setno_telepon(String no_telepon) {
        this.no_telepon = no_telepon;
    }
    
    public int getmasa_kerja() {
        return masa_kerja;
    }

    public void setmasa_kerja(int masa_kerja) {
        this.masa_kerja = masa_kerja;
    }
    
    public int getgaji() {
        return gaji;
    }

    public void setgaji(int gaji) {
        this.gaji = gaji;
    }
}
