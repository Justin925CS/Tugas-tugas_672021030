/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Connection.HotelConnection;
import TR_Hotel.Pegawai;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class PegawaiDAO {
    private Connection con = null;

    public PegawaiDAO() {
        this.con = new HotelConnection().getConnection();
    }

    public List<Pegawai> getAll() {
        List<Pegawai> employee = new ArrayList<Pegawai>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM pegawai");
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Pegawai pg = new Pegawai();
                pg.setkode_pegawai(rs.getString("kode_Pegawai"));
                pg.setnama_pegawai(rs.getString("Nama_Pegawai"));                
                pg.setgender_pegawai(rs.getString("Gender_Pegawai"));
                pg.setposisi(rs.getString("Posisi"));                
                pg.setalamat(rs.getString("Alamat"));
                pg.setno_telepon(rs.getString("No_Telepon"));
                pg.setmasa_kerja(rs.getInt("Masa_Kerja"));
                pg.setgaji(rs.getInt("Gaji"));
                employee.add(pg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }

    public List<Pegawai> getkode_pegawai(String kode) {
        List<Pegawai> employee = new ArrayList<Pegawai>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM pegawai where Kode_Pegawai =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Pegawai pg = new Pegawai();
                pg.setkode_pegawai(rs.getString("kode_Pegawai"));
                pg.setnama_pegawai(rs.getString("Nama_Pegawai"));                
                pg.setgender_pegawai(rs.getString("Gender_Pegawai"));
                pg.setposisi(rs.getString("Posisi"));                
                pg.setalamat(rs.getString("Alamat"));
                pg.setno_telepon(rs.getString("No_Telepon"));
                pg.setmasa_kerja(rs.getInt("Masa_Kerja"));
                pg.setgaji(rs.getInt("Gaji"));
                employee.add(pg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }
    
    public List<Pegawai> getnama_pegawai(String kode) {
        List<Pegawai> employee = new ArrayList<Pegawai>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM pegawai where Nama_Pegawai =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Pegawai pg = new Pegawai();
                pg.setkode_pegawai(rs.getString("kode_Pegawai"));
                pg.setnama_pegawai(rs.getString("Nama_Pegawai"));                
                pg.setgender_pegawai(rs.getString("Gender_Pegawai"));
                pg.setposisi(rs.getString("Posisi"));                
                pg.setalamat(rs.getString("Alamat"));
                pg.setno_telepon(rs.getString("No_Telepon"));
                pg.setmasa_kerja(rs.getInt("Masa_Kerja"));
                pg.setgaji(rs.getInt("Gaji"));
                employee.add(pg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }
       
    public List<Pegawai> getgender_pegawai(String kode) {
        List<Pegawai> employee = new ArrayList<Pegawai>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM pegawai where Gender_Pegawai =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Pegawai pg = new Pegawai();
                pg.setkode_pegawai(rs.getString("kode_Pegawai"));
                pg.setnama_pegawai(rs.getString("Nama_Pegawai"));                
                pg.setgender_pegawai(rs.getString("Gender_Pegawai"));
                pg.setposisi(rs.getString("Posisi"));                
                pg.setalamat(rs.getString("Alamat"));
                pg.setno_telepon(rs.getString("No_Telepon"));
                pg.setmasa_kerja(rs.getInt("Masa_Kerja"));
                pg.setgaji(rs.getInt("Gaji"));
                employee.add(pg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }

    public List<Pegawai> getposisi(String kode) {
        List<Pegawai> employee = new ArrayList<Pegawai>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM pegawai where Posisi =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Pegawai pg = new Pegawai();
                pg.setkode_pegawai(rs.getString("kode_Pegawai"));
                pg.setnama_pegawai(rs.getString("Nama_Pegawai"));                
                pg.setgender_pegawai(rs.getString("Gender_Pegawai"));
                pg.setposisi(rs.getString("Posisi"));                
                pg.setalamat(rs.getString("Alamat"));
                pg.setno_telepon(rs.getString("No_Telepon"));
                pg.setmasa_kerja(rs.getInt("Masa_Kerja"));
                pg.setgaji(rs.getInt("Gaji"));
                employee.add(pg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }

    public List<Pegawai> getalamat(String kode) {
        List<Pegawai> employee = new ArrayList<Pegawai>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM pegawai where Alamat =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Pegawai pg = new Pegawai();
                pg.setkode_pegawai(rs.getString("kode_Pegawai"));
                pg.setnama_pegawai(rs.getString("Nama_Pegawai"));                
                pg.setgender_pegawai(rs.getString("Gender_Pegawai"));
                pg.setposisi(rs.getString("Posisi"));                
                pg.setalamat(rs.getString("Alamat"));
                pg.setno_telepon(rs.getString("No_Telepon"));
                pg.setmasa_kerja(rs.getInt("Masa_Kerja"));
                pg.setgaji(rs.getInt("Gaji"));
                employee.add(pg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }

    public List<Pegawai> getno_telepon(String kode) {
        List<Pegawai> employee = new ArrayList<Pegawai>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM pegawai where No_Telepon =?");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Pegawai pg = new Pegawai();
                pg.setkode_pegawai(rs.getString("kode_Pegawai"));
                pg.setnama_pegawai(rs.getString("Nama_Pegawai"));                
                pg.setgender_pegawai(rs.getString("Gender_Pegawai"));
                pg.setposisi(rs.getString("Posisi"));                
                pg.setalamat(rs.getString("Alamat"));
                pg.setno_telepon(rs.getString("No_Telepon"));
                pg.setmasa_kerja(rs.getInt("Masa_Kerja"));
                pg.setgaji(rs.getInt("Gaji"));
                employee.add(pg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }
    
    public List<Pegawai> getmasa_kerja(int kode) {
        List<Pegawai> employee = new ArrayList<Pegawai>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM pegawai where Masa_Kerja =?");
            stm.setInt(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Pegawai pg = new Pegawai();
                pg.setkode_pegawai(rs.getString("kode_Pegawai"));
                pg.setnama_pegawai(rs.getString("Nama_Pegawai"));                
                pg.setgender_pegawai(rs.getString("Gender_Pegawai"));
                pg.setposisi(rs.getString("Posisi"));                
                pg.setalamat(rs.getString("Alamat"));
                pg.setno_telepon(rs.getString("No_Telepon"));
                pg.setmasa_kerja(rs.getInt("Masa_Kerja"));
                pg.setgaji(rs.getInt("Gaji"));
                employee.add(pg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }
    
    public List<Pegawai> getgaji(int kode) {
        List<Pegawai> employee = new ArrayList<Pegawai>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM pegawai where Gaji =?");
            stm.setInt(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Pegawai pg = new Pegawai();
                pg.setnama_pegawai(rs.getString("Nama_Pegawai"));                
                pg.setgender_pegawai(rs.getString("Gender_Pegawai"));
                pg.setposisi(rs.getString("Posisi"));                
                pg.setalamat(rs.getString("Alamat"));
                pg.setno_telepon(rs.getString("No_Telepon"));
                pg.setmasa_kerja(rs.getInt("Masa_Kerja"));
                pg.setgaji(rs.getInt("Gaji"));
                employee.add(pg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }
    
    public String insertPegawai(Pegawai employee) {
        String status = "Gagal";
        try {
            PreparedStatement ps = con.prepareStatement(""
                    + "INSERT INTO pegawai VALUE(?,?,?,?,?,?,?,?)");
            ps.setString(1, employee.getkode_pegawai());
            ps.setString(2, employee.getnama_pegawai());
            ps.setString(3, employee.getgender_pegawai());
            ps.setString(4, employee.getposisi());
            ps.setString(5, employee.getalamat());
            ps.setString(6, employee.getno_telepon());
            ps.setInt(7, employee.getmasa_kerja());
            ps.setInt(8, employee.getgaji());

            ps.executeUpdate();
            status = "Data berhasil disimpan";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public String hapusPegawai(String kode) {
        String status = "Gagal";
        try {
            PreparedStatement ps = con.prepareStatement(""
                    + "DELETE FROM pegawai WHERE Kode_Pegawai=?");
            ps.setString(1, kode);
            ps.executeUpdate();
            status = "Data Berhasil Dihapus";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public String updatePegawai(String kode, Pegawai pg) {
        String status = "Gagal";
        try {
            PreparedStatement ps = con.prepareStatement(""
                    + "UPDATE pegawai set Nama_Pegawai=?,"
                    + "Gender_Pegawai=?, Posisi=?, Alamat=?, No_Telepon=?, Masa_Kerja=?,"
                    + "Gaji=? WHERE Kode_Pegawai=?");
            ps.setString(1, pg.getkode_pegawai());
            ps.setString(2, pg.getnama_pegawai());
            ps.setString(3, pg.getgender_pegawai());
            ps.setString(4, pg.getposisi());
            ps.setString(5, pg.getalamat());
            ps.setString(6, pg.getno_telepon());
            ps.setInt(7, pg.getmasa_kerja());
            ps.setInt(8, pg.getgaji());
            ps.executeUpdate();
            status = "Data Berhasil Diupdate";
        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    public boolean cekkode(String kode) {
        boolean cek = false;
        String hasil = "";
        try {
            PreparedStatement stm = con.prepareStatement("SELECT Nama_Pegawai FROM pegawai WHERE Kode_Pegawai=?");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                hasil = rs.getString("Nama_Pegawai");
            }
            if (!hasil.equals("")) {
                cek = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cek;
    }
}
