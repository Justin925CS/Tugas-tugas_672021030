/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Connection.HotelConnection;
import TR_Hotel.Reservasi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class ReservasiDAO {
    private Connection con = null;
    
    public ReservasiDAO() {
        this.con = new HotelConnection().getConnection();
    }
    
    public List<Reservasi> getAll() {
        List<Reservasi> rsvp = new ArrayList<Reservasi>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM tamu");
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Reservasi rv = new Reservasi();
                rv.setno_pesan(rs.getString("No_Reservasi"));
                rv.setnama_tamu(rs.getString("Nama_Tamu"));                
                rv.setgender_tamu(rs.getString("Gender_Tamu"));   
                rv.setalamat(rs.getString("Alamat"));
                rv.setjenis_kamar(rs.getString("Tipe_Kamar"));
                rv.setharga(rs.getInt("Harga"));
                rv.setlama_inap(rs.getInt("Lama_Inap"));
                rv.settotal(rs.getInt("Total"));
                rsvp.add(rv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rsvp;
    }
    
    public List<Reservasi> getno_pesan(String kode) {
        List<Reservasi> rsvp = new ArrayList<Reservasi>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM tamu where No_Reservasi =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Reservasi rv = new Reservasi();
                rv.setno_pesan(rs.getString("No_Reservasi"));
                rv.setnama_tamu(rs.getString("Nama_Tamu"));                
                rv.setgender_tamu(rs.getString("Gender_Tamu"));   
                rv.setalamat(rs.getString("Alamat"));
                rv.setjenis_kamar(rs.getString("Tipe_Kamar"));
                rv.setharga(rs.getInt("Harga"));
                rv.setlama_inap(rs.getInt("Lama_Inap"));
                rv.settotal(rs.getInt("Total"));
                rsvp.add(rv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rsvp;
    }
    
    public List<Reservasi> getnama_tamu(String kode) {
        List<Reservasi> rsvp = new ArrayList<Reservasi>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM tamu where Nama_Tamu =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Reservasi rv = new Reservasi();
                rv.setno_pesan(rs.getString("No_Reservasi"));
                rv.setnama_tamu(rs.getString("Nama_Tamu"));                
                rv.setgender_tamu(rs.getString("Gender_Tamu"));   
                rv.setalamat(rs.getString("Alamat"));
                rv.setjenis_kamar(rs.getString("Tipe_Kamar"));
                rv.setharga(rs.getInt("Harga"));
                rv.setlama_inap(rs.getInt("Lama_Inap"));
                rv.settotal(rs.getInt("Total"));
                rsvp.add(rv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rsvp;
    }
    
    public List<Reservasi> getgender_tamu(String kode) {
        List<Reservasi> rsvp = new ArrayList<Reservasi>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM tamu where Gender_Tamu =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Reservasi rv = new Reservasi();
                rv.setno_pesan(rs.getString("No_Reservasi"));
                rv.setnama_tamu(rs.getString("Nama_Tamu"));                
                rv.setgender_tamu(rs.getString("Gender_Tamu"));   
                rv.setalamat(rs.getString("Alamat"));
                rv.setjenis_kamar(rs.getString("Tipe_Kamar"));
                rv.setharga(rs.getInt("Harga"));
                rv.setlama_inap(rs.getInt("Lama_Inap"));
                rv.settotal(rs.getInt("Total"));
                rsvp.add(rv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rsvp;
    }
    
    public List<Reservasi> getalamat(String kode) {
        List<Reservasi> rsvp = new ArrayList<Reservasi>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM tamu where Alamat =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Reservasi rv = new Reservasi();
                rv.setno_pesan(rs.getString("No_Reservasi"));
                rv.setnama_tamu(rs.getString("Nama_Tamu"));                
                rv.setgender_tamu(rs.getString("Gender_Tamu"));   
                rv.setalamat(rs.getString("Alamat"));
                rv.setjenis_kamar(rs.getString("Tipe_Kamar"));
                rv.setharga(rs.getInt("Harga"));
                rv.setlama_inap(rs.getInt("Lama_Inap"));
                rv.settotal(rs.getInt("Total"));
                rsvp.add(rv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rsvp;
    }
    
    public List<Reservasi> getjenis_kamar(String kode) {
        List<Reservasi> rsvp = new ArrayList<Reservasi>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM tamu where Tipe_Kamar =? ");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Reservasi rv = new Reservasi();
                rv.setno_pesan(rs.getString("No_Reservasi"));
                rv.setnama_tamu(rs.getString("Nama_Tamu"));                
                rv.setgender_tamu(rs.getString("Gender_Tamu"));   
                rv.setalamat(rs.getString("Alamat"));
                rv.setjenis_kamar(rs.getString("Tipe_Kamar"));
                rv.setharga(rs.getInt("Harga"));
                rv.setlama_inap(rs.getInt("Lama_Inap"));
                rv.settotal(rs.getInt("Total"));
                rsvp.add(rv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rsvp;
    }
    
    public List<Reservasi> getharga(int kode) {
        List<Reservasi> rsvp = new ArrayList<Reservasi>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM tamu where Harga =? ");
            stm.setInt(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Reservasi rv = new Reservasi();
                rv.setno_pesan(rs.getString("No_Reservasi"));
                rv.setnama_tamu(rs.getString("Nama_Tamu"));                
                rv.setgender_tamu(rs.getString("Gender_Tamu"));   
                rv.setalamat(rs.getString("Alamat"));
                rv.setjenis_kamar(rs.getString("Tipe_Kamar"));
                rv.setharga(rs.getInt("Harga"));
                rv.setlama_inap(rs.getInt("Lama_Inap"));
                rv.settotal(rs.getInt("Total"));
                rsvp.add(rv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rsvp;
    }
    
    public List<Reservasi> getlama_inap(int kode) {
        List<Reservasi> rsvp = new ArrayList<Reservasi>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM tamu where Lama_Inap =? ");
            stm.setInt(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Reservasi rv = new Reservasi();
                rv.setno_pesan(rs.getString("No_Reservasi"));
                rv.setnama_tamu(rs.getString("Nama_Tamu"));                
                rv.setgender_tamu(rs.getString("Gender_Tamu"));   
                rv.setalamat(rs.getString("Alamat"));
                rv.setjenis_kamar(rs.getString("Tipe_Kamar"));
                rv.setharga(rs.getInt("Harga"));
                rv.setlama_inap(rs.getInt("Lama_Inap"));
                rv.settotal(rs.getInt("Total"));
                rsvp.add(rv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rsvp;
    }
    
    public List<Reservasi> gettotal(int kode) {
        List<Reservasi> rsvp = new ArrayList<Reservasi>();
        try {
            PreparedStatement stm = con.prepareStatement("SELECT * FROM tamu where Total =? ");
            stm.setInt(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Reservasi rv = new Reservasi();
                rv.setno_pesan(rs.getString("No_Reservasi"));
                rv.setnama_tamu(rs.getString("Nama_Tamu"));                
                rv.setgender_tamu(rs.getString("Gender_Tamu"));   
                rv.setalamat(rs.getString("Alamat"));
                rv.setjenis_kamar(rs.getString("Tipe_Kamar"));
                rv.setharga(rs.getInt("Harga"));
                rv.setlama_inap(rs.getInt("Lama_Inap"));
                rv.settotal(rs.getInt("Total"));
                rsvp.add(rv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rsvp;
    }
    
    public String insertTamu(Reservasi rsvp) {
        String status = "Gagal";
        try {
            PreparedStatement ps = con.prepareStatement(""
                    + "INSERT INTO tamu VALUE(?,?,?,?,?,?,?,?)");
            ps.setString(1, rsvp.getno_pesan());
            ps.setString(2, rsvp.getnama_tamu());
            ps.setString(3, rsvp.getgender_tamu());
            ps.setString(4, rsvp.getalamat());
            ps.setString(5, rsvp.getgender_tamu());
            ps.setInt(6, rsvp.getharga());
            ps.setInt(7, rsvp.getlama_inap());
            ps.setInt(8, rsvp.gettotal());

            ps.executeUpdate();
            status = "Data berhasil disimpan";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
    
    public String hapusTamu(String kode) {
        String status = "Gagal";
        try {
            PreparedStatement ps = con.prepareStatement(""
                    + "DELETE FROM tamu WHERE No_Reservasi=?");
            ps.setString(1, kode);
            ps.executeUpdate();
            status = "Data Berhasil Dihapus";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
    
    public String updateTamu(String kode, Reservasi rv) {
        String status = "Gagal";
        try {
            PreparedStatement ps = con.prepareStatement(""
                    + "UPDATE tamu set Nama_Tamu=?,"
                    + "Gender_Tamu=?, Alamat=?, Tipe_Kamar=?, Harga=?, Lama_Inap=?"
                    + "Total=? WHERE Kode_Pegawai=?");
            ps.setString(1, rv.getno_pesan());
            ps.setString(2, rv.getnama_tamu());
            ps.setString(3, rv.getgender_tamu());
            ps.setString(4, rv.getalamat());
            ps.setString(5, rv.getgender_tamu());
            ps.setInt(6, rv.getharga());
            ps.setInt(7, rv.getlama_inap());
            ps.setInt(8, rv.gettotal());
            ps.executeUpdate();
            status = "Data Berhasil Diupdate";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
    
    public boolean cekkode(String kode) {
        boolean cek = false;
        String hasil = "";
        try {
            PreparedStatement stm = con.prepareStatement("SELECT Nama_Tamu FROM tamu WHERE No_Reservasi=?");
            stm.setString(1, kode);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                hasil = rs.getString("Nama_Pegawai");
            }
            if (!hasil.equals("")) {
                cek = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cek;
    }
    
}
